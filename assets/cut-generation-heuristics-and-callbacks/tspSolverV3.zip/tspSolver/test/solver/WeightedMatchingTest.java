package solver;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ilog.concert.IloException;
import ilog.cplex.IloCplex;
import instances.IntNode;

import org.junit.Test;

import com.google.common.base.Functions;

import solver.WeightedMatching.ObjectiveType;

import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;

public class WeightedMatchingTest {
	
	private static class Edge{	
		private String name;
		public Edge(String name) {
			super();
			this.name = name;
		}		
		public String toString(){
			return this.name;
		}
	}
	
	
	
	private static class CompleteGraph{
		private UndirectedGraph<IntNode,Edge> graph;
		private List<IntNode> nodesByIndex;
		private Map<Edge,Double> edgeWeight;
		
		public CompleteGraph(int numNodes, double defaultWeight){
			graph = new UndirectedSparseGraph<IntNode,Edge>();
			nodesByIndex = new ArrayList<IntNode>();
			this.edgeWeight = new HashMap<Edge,Double>();
			for(int i = 0; i < numNodes; i++){
				IntNode node = new IntNode(i);
				graph.addVertex(node);
				nodesByIndex.add(node);
			}
			for(int i = 0; i < numNodes; i++){
				for(int j = i+1; j < numNodes; j++){
					Edge edge = new Edge(i + "-" + j);
					graph.addEdge(edge, this.nodesByIndex.get(i), this.nodesByIndex.get(j));
					edgeWeight.put(edge, Double.valueOf(defaultWeight));
				}
			}
		}

		public UndirectedGraph<IntNode, Edge> getGraph() {
			return graph;
		}

		public List<IntNode> getNodes() {
			return nodesByIndex;
		}

		public Map<Edge, Double> getEdgeWeight() {
			return edgeWeight;
		}
		
	}

	@Test
	public void testSmall() {
		CompleteGraph completeGraph = new CompleteGraph(4,1);
		List<IntNode> nodes = completeGraph.getNodes();
		UndirectedGraph<IntNode,Edge> graph = completeGraph.getGraph();
		Map<Edge,Double> edgeWeight = completeGraph.getEdgeWeight();
		edgeWeight.put(graph.findEdge(nodes.get(0), nodes.get(1)),Double.valueOf(10));
		edgeWeight.put(graph.findEdge(nodes.get(0), nodes.get(2)),Double.valueOf(9));
		edgeWeight.put(graph.findEdge(nodes.get(1), nodes.get(3)),Double.valueOf(8));
		
		try {
			WeightedMatching<IntNode,Edge> matching = new WeightedMatching<IntNode,Edge>(graph,Functions.forMap(edgeWeight),ObjectiveType.maximize);
			matching.solve();
			Set<Edge> solution = matching.getEdgesInOpt(); 
			assertEquals(2,solution.size());
			assertTrue(solution.contains(graph.findEdge(nodes.get(0), nodes.get(2))));
			assertTrue(solution.contains(graph.findEdge(nodes.get(1), nodes.get(3))));
		} catch (IloException e) {
			throw new RuntimeException(e);
		}
	}
	
	@Test
	public void testMedium() {
		CompleteGraph completeGraph = new CompleteGraph(6,1);
		List<IntNode> nodes = completeGraph.getNodes();
		UndirectedGraph<IntNode,Edge> graph = completeGraph.getGraph();
		Map<Edge,Double> edgeWeight = completeGraph.getEdgeWeight();
		edgeWeight.put(graph.findEdge(nodes.get(0), nodes.get(1)),Double.valueOf(10));
		edgeWeight.put(graph.findEdge(nodes.get(2), nodes.get(3)),Double.valueOf(10));
		edgeWeight.put(graph.findEdge(nodes.get(4), nodes.get(5)),Double.valueOf(5));
		edgeWeight.put(graph.findEdge(nodes.get(0), nodes.get(2)),Double.valueOf(11));
		edgeWeight.put(graph.findEdge(nodes.get(1), nodes.get(5)),Double.valueOf(12));
		try {
			WeightedMatching<IntNode,Edge> matching = new WeightedMatching<IntNode,Edge>(graph,Functions.forMap(edgeWeight),ObjectiveType.maximize);
			matching.solve();
			Set<Edge> solution = matching.getEdgesInOpt(); 
			assertEquals(3,solution.size());
			assertTrue(solution.contains(graph.findEdge(nodes.get(0), nodes.get(1))));
			assertTrue(solution.contains(graph.findEdge(nodes.get(2), nodes.get(3))));
			assertTrue(solution.contains(graph.findEdge(nodes.get(4), nodes.get(5))));
		} catch (IloException e) {
			throw new RuntimeException(e);
		}
	}
	
	@Test
	public void testLarge() {
		int n = 300;//must be even
		CompleteGraph completeGraph = new CompleteGraph(n,1);
		List<IntNode> nodes = completeGraph.getNodes();
		UndirectedGraph<IntNode,Edge> graph = completeGraph.getGraph();
		Map<Edge,Double> edgeWeight = completeGraph.getEdgeWeight();
		for(int i = 0; i < n; i+=2){
			edgeWeight.put(graph.findEdge(nodes.get(i), nodes.get(i+1)),Double.valueOf(5));
			for(int j = i; j < n; j+=2){
				edgeWeight.put(graph.findEdge(nodes.get(i), nodes.get(j)),Double.valueOf(7));
			}			
		}
		try {
			WeightedMatching<IntNode,Edge> matching = new WeightedMatching<IntNode,Edge>(graph,Functions.forMap(edgeWeight),ObjectiveType.maximize);
			matching.solve();
			Set<Edge> solution = matching.getEdgesInOpt(); 
			
			assertEquals(n/2,solution.size());
			for(int i = 0; i < n; i+=2){
				assertTrue(solution.contains(graph.findEdge(nodes.get(i), nodes.get(i+1))));
			}
		} catch (IloException e) {
			throw new RuntimeException(e);
		}
	}
	
	


}
