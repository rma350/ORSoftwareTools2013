package solver;

import static org.junit.Assert.*;

import java.util.EnumSet;

import ilog.concert.IloException;
import instances.TspInstance;

import org.junit.Test;

import solver.TspIpSolver.Option;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableSet;

import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;

public class TspSolverTest {
	
	private static double tolerance = .00001;
	
	private static String graphName = "Simple Test Graph";
	
	private static enum Node{
		a,b,c,d,e,f;
	}
	
	private static enum Edge{
		ab(Node.a,Node.b,1),bc(Node.b,Node.c,1),ac(Node.a,Node.c,1),
		bd(Node.b,Node.d,10),ce(Node.c,Node.e,10),de(Node.d,Node.e,1),
		df(Node.d,Node.f,1),ef(Node.e,Node.f,1);
		
		private Node first;
		private Node second;
		private int weight;
		
		private Edge(Node first, Node second, int weight){
			this.weight = weight;
			this.first = first;
			this.second = second;
		}

		public Node getFirst() {
			return first;
		}

		public Node getSecond() {
			return second;
		}

		public int getWeight() {
			return weight;
		}
	}
	
	private static Function<Edge,Integer> makeEdgeWeights(){
		return new Function<Edge,Integer>(){
			@Override
			public Integer apply(Edge edge) {
				return edge.getWeight();
			}};
	}

	
	private static TspInstance<Node,Edge> makeGraph(){
		UndirectedGraph<Node,Edge> graph = new UndirectedSparseGraph<Node,Edge>();
		for(Node node: Node.values()){
			graph.addVertex(node);
		}
		for(Edge edge: Edge.values()){
			graph.addEdge(edge, edge.getFirst(),edge.getSecond());
		}			
		return new TspInstance<Node,Edge>(graph, makeEdgeWeights(), graphName);
	}
	
	
	@Test
	public void testDegreeConstraints(){
		TspInstance<Node,Edge> instance = makeGraph();
		try {
			TspIpSolver<Node,Edge> solver = new TspIpSolver<Node,Edge>(instance,EnumSet.noneOf(Option.class));
			solver.solve();
			assertEquals(6,solver.getOptVal(),tolerance);
			ImmutableSet<Edge> edgesUsed = solver.getEdgesInOpt();
			assertEquals(edgesUsed,ImmutableSet.of(Edge.ab,Edge.bc,Edge.ac,
					Edge.de,Edge.df,Edge.ef));
		}
		catch (IloException e) {
			throw new RuntimeException(e);
		}
	}
	
	@Test
	public void testCutsetLazy(){
		TspInstance<Node,Edge> instance = makeGraph();
		try {
			TspIpSolver<Node,Edge> solver = new TspIpSolver<Node,Edge>(instance,EnumSet.of(Option.lazy));
			solver.solve();
			assertEquals(24,solver.getOptVal(),tolerance);
			ImmutableSet<Edge> edgesUsed = solver.getEdgesInOpt();
			assertEquals(edgesUsed,ImmutableSet.of(Edge.ab,Edge.bd,Edge.ac,
					Edge.ef,Edge.df,Edge.ce));
			
		}
		catch (IloException e) {
			throw new RuntimeException(e);
		}
	}

}
