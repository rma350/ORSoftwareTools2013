package solver;

import static org.junit.Assert.*;

import ilog.concert.IloException;
import instances.TspInstance;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import com.google.common.base.Function;

import edu.uci.ics.jung.algorithms.cluster.WeakComponentClusterer;
import edu.uci.ics.jung.algorithms.filters.EdgePredicateFilter;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;

public class ChristofidesSolverTest {
	
	//taken from http://www.cs.tufts.edu/comp/260/tspscribe-final.pdf
	//but changed ab from 10 to 11 and em from 9 to 10 to make MST unique
	private enum City{
		a,b,c,e,m,s;
	}
	
	private enum Edge{		
		ab(City.a,City.b,11),
		ac(City.a,City.c,15),
		ae(City.a,City.e,14),
		am(City.a,City.m,11),
		as(City.a,City.s,10),
		
		bc(City.b,City.c,8),
		be(City.b,City.e,13),
		bm(City.b,City.m,14),
		bs(City.b,City.s,9),
		
		ce(City.c,City.e,11),
		cm(City.c,City.m,16),
		cs(City.c,City.s,10),
		
		em(City.e,City.m,10),
		es(City.e,City.s,6),
		
		ms(City.m,City.s,9);
		
		
		private Edge(City c1, City c2, int distance){
			this.c1 = c1;
			this.c2 = c2;
			this.distance = distance;
		}
		
		private City c1;
		private City c2;
		private int distance;
		public City getC1() {
			return c1;
		}
		public City getC2() {
			return c2;
		}
		public int getDistance() {
			return distance;
		}	
		
	}
	
	public static UndirectedGraph<City,Edge> makeGraph(){
		UndirectedGraph<City,Edge> ans = new UndirectedSparseGraph<City,Edge>();
		for(City city: City.values()){
			ans.addVertex(city);
		}
		for(Edge edge : Edge.values()){
			ans.addEdge(edge, edge.getC1(), edge.getC2());
		}
		return ans;
	}
	
	public static Function<Edge,Integer> makeCost(){
		return new Function<Edge,Integer>(){
			@Override
			public Integer apply(Edge arg0) {
				return arg0.getDistance();
			}};
	}

	@Test
	public void test() {
		UndirectedGraph<City,Edge> graph = makeGraph();
		Function<Edge,Integer> costs = makeCost();
		ChristofidesSolver<City,Edge> solver = new ChristofidesSolver<City,Edge>(graph, costs);
		List<Edge> approxTour;
		try {
			approxTour = solver.approximateBestTour(new HashSet<Edge>());
		} catch (IloException e) {
			throw new RuntimeException(e);
		}
		assertEquals(6,approxTour.size());
		EdgePredicateFilter<City,Edge> filter = new EdgePredicateFilter<City,Edge>(Util.inSet(new HashSet<Edge>(approxTour)));
		Graph<City,Edge> tour = filter.transform(graph);
		WeakComponentClusterer<City,Edge> clusterer = new WeakComponentClusterer<City,Edge>();
		assertEquals(1,clusterer.transform(tour).size());
		double tourWeight = 0;
		for(Edge edge: approxTour){
			tourWeight += edge.getDistance(); 
		}
		assertTrue(tourWeight <= 1.5*56);
		
		/*
		 * Calculates that best tour is of length 56
		try {
			TspIpSolver<City,Edge> ipSolver = new TspIpSolver<City,Edge>(new TspInstance<City,Edge>(graph,costs,"test"),true,false,false);
			ipSolver.solve();
			System.out.println("best is: " + ipSolver.getOptVal());
		} catch (IloException e) {
			throw new RuntimeException(e);
		}
		*/
		
		/*Set<Edge> solutionA = new HashSet<Edge>();
		solutionA.add(Edge.as);
		solutionA.add(Edge.am);		
		solutionA.add(Edge.bm);
		solutionA.add(Edge.bc);
		solutionA.add(Edge.ce);
		solutionA.add(Edge.es);
		
		Set<Edge> solutionB = new HashSet<Edge>();
		solutionA.add(Edge.as);
		solutionA.add(Edge.am);
		solutionA.add(Edge.em);
		solutionA.add(Edge.ce);
		solutionA.add(Edge.bc);
		solutionA.add(Edge.bs);*/
		
		
		
		
		
		
	}

}
