package solver;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import instances.IntNode;
import instances.TspInstance;
import instances.WeightedEdge;

import org.junit.Test;

import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;

public class TwoOptTest {
	
	private static class TestEdge<V> extends WeightedEdge{
		private V first;
		private V second;
		
		public TestEdge(int weight, V first, V second){
			super(weight);
			this.first = first;
			this.second = second;
		}
		
		public String toString(){
			return "(" + first.toString()+","+second.toString()+")";
		}
	}

	@Test
	public void testBasic() {
		UndirectedGraph<IntNode,WeightedEdge> graph = new UndirectedSparseGraph<IntNode,WeightedEdge>();
		List<IntNode> nodes = new ArrayList<IntNode>();
		int size = 10;
		for(int i = 0; i < size; i++){
			IntNode node = new IntNode(i);
			nodes.add(node);
			graph.addVertex(node);
		}
		for(int i = 0; i < size; i++ ){
			IntNode nodeI = nodes.get(i);
			for(int j = i+1; j < size; j++){
				IntNode nodeJ = nodes.get(j);
				int weight;
				if(i == 3 && j == 7){
					weight = 1;
				}
				else if(i == 4 && j == 8){
					weight = 1;
				}
				else{
					weight = 2;
				}
				graph.addEdge(new TestEdge<IntNode>(weight,nodeI,nodeJ),nodeI,nodeJ);
			}
		}
		TspInstance<IntNode,WeightedEdge> instance = new TspInstance<IntNode,WeightedEdge>(graph,WeightedEdge.edgeWeights,"simple test");
		TwoOpt<IntNode,WeightedEdge> twoOptSolver = new TwoOpt<IntNode,WeightedEdge>(instance);
		
		List<IntNode> twoOptSol = new ArrayList<IntNode>();
		twoOptSol.add(nodes.get(0));
		twoOptSol.add(nodes.get(1));
		twoOptSol.add(nodes.get(2));
		twoOptSol.add(nodes.get(3));
		twoOptSol.add(nodes.get(7));
		twoOptSol.add(nodes.get(6));
		twoOptSol.add(nodes.get(5));
		twoOptSol.add(nodes.get(4));
		twoOptSol.add(nodes.get(8));
		twoOptSol.add(nodes.get(9));
		
		List<WeightedEdge> actualTwoOptEdgeConv = twoOptSolver.toEdgeFormat(twoOptSol);
		
		List<WeightedEdge> expectedTwoOptEdgeConv = new ArrayList<WeightedEdge>();
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(0), nodes.get(1)));
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(1), nodes.get(2)));
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(2), nodes.get(3)));
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(3), nodes.get(7)));
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(7), nodes.get(6)));
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(6), nodes.get(5)));
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(5), nodes.get(4)));
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(4), nodes.get(8)));
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(8), nodes.get(9)));
		expectedTwoOptEdgeConv.add(graph.findEdge(nodes.get(9), nodes.get(0)));
		
		assertEquals(expectedTwoOptEdgeConv,actualTwoOptEdgeConv);
		
		Set<WeightedEdge> expectedTwoOpt = new HashSet<WeightedEdge>(expectedTwoOptEdgeConv);
		
		Set<WeightedEdge> actualTwoOptDepthOne = twoOptSolver.searchNeighborhood(nodes, 1);
		
		assertEquals(expectedTwoOpt,actualTwoOptDepthOne );
		
		Set<WeightedEdge> repeat = twoOptSolver.searchNeighborhood(nodes,20);
		assertNull(repeat);
		
		Set<WeightedEdge> solRepeat = twoOptSolver.searchNeighborhood(twoOptSol,20);
		assertNull(solRepeat);
		
		
		TwoOpt<IntNode,WeightedEdge> twoOptSolverNew = new TwoOpt<IntNode,WeightedEdge>(instance);
		Set<WeightedEdge> moreDepth = twoOptSolverNew.searchNeighborhood(nodes,20);
		assertEquals(expectedTwoOpt,moreDepth );
	}
	
	@Test
	public void testTourStartCorner() {
		UndirectedGraph<IntNode,WeightedEdge> graph = new UndirectedSparseGraph<IntNode,WeightedEdge>();
		List<IntNode> nodes = new ArrayList<IntNode>();
		int size = 10;
		for(int i = 0; i < size; i++){
			IntNode node = new IntNode(i);
			nodes.add(node);
			graph.addVertex(node);
		}
		for(int i = 0; i < size; i++ ){
			IntNode nodeI = nodes.get(i);
			for(int j = i+1; j < size; j++){
				IntNode nodeJ = nodes.get(j);
				int weight;
				if(i == 0 && j == 7){
					weight = 1;
				}
				else if(i == 1 && j == 8){
					weight = 1;
				}
				else{
					weight = 2;
				}
				graph.addEdge(new TestEdge<IntNode>(weight,nodeI,nodeJ),nodeI,nodeJ);
			}
		}
		TspInstance<IntNode,WeightedEdge> instance = new TspInstance<IntNode,WeightedEdge>(graph,WeightedEdge.edgeWeights,"simple test");
		TwoOpt<IntNode,WeightedEdge> twoOptSolver = new TwoOpt<IntNode,WeightedEdge>(instance);
		
		List<IntNode> twoOptSol = new ArrayList<IntNode>();
		twoOptSol.add(nodes.get(0));
		twoOptSol.add(nodes.get(7));
		twoOptSol.add(nodes.get(6));
		twoOptSol.add(nodes.get(5));
		twoOptSol.add(nodes.get(4));
		twoOptSol.add(nodes.get(3));
		twoOptSol.add(nodes.get(2));
		twoOptSol.add(nodes.get(1));
		twoOptSol.add(nodes.get(8));
		twoOptSol.add(nodes.get(9));
		
		List<WeightedEdge> twoOptEdgeConv = twoOptSolver.toEdgeFormat(twoOptSol);
		Set<WeightedEdge> expectedTwoOpt = new HashSet<WeightedEdge>(twoOptEdgeConv);
		
		Set<WeightedEdge> actualTwoOpt = twoOptSolver.searchNeighborhood(nodes, 20);
		
		assertEquals(expectedTwoOpt,actualTwoOpt );
		
	}
	
	@Test
	public void testTourEndCorner() {
		UndirectedGraph<IntNode,WeightedEdge> graph = new UndirectedSparseGraph<IntNode,WeightedEdge>();
		List<IntNode> nodes = new ArrayList<IntNode>();
		int size = 10;
		for(int i = 0; i < size; i++){
			IntNode node = new IntNode(i);
			nodes.add(node);
			graph.addVertex(node);
		}
		for(int i = 0; i < size; i++ ){
			IntNode nodeI = nodes.get(i);
			for(int j = i+1; j < size; j++){
				IntNode nodeJ = nodes.get(j);
				int weight;
				if(i == 3 && j == 8){
					weight = 1;
				}
				else if(i == 4 && j == 9){
					weight = 1;
				}
				else{
					weight = 2;
				}
				graph.addEdge(new TestEdge<IntNode>(weight,nodeI,nodeJ),nodeI,nodeJ);
			}
		}
		TspInstance<IntNode,WeightedEdge> instance = new TspInstance<IntNode,WeightedEdge>(graph,WeightedEdge.edgeWeights,"simple test");
		TwoOpt<IntNode,WeightedEdge> twoOptSolver = new TwoOpt<IntNode,WeightedEdge>(instance);
		
		List<IntNode> twoOptSol = new ArrayList<IntNode>();
		twoOptSol.add(nodes.get(0));
		twoOptSol.add(nodes.get(1));
		twoOptSol.add(nodes.get(2));
		twoOptSol.add(nodes.get(3));
		twoOptSol.add(nodes.get(8));
		twoOptSol.add(nodes.get(7));
		twoOptSol.add(nodes.get(6));
		twoOptSol.add(nodes.get(5));
		twoOptSol.add(nodes.get(4));
		twoOptSol.add(nodes.get(9));
		
		List<WeightedEdge> twoOptEdgeConv = twoOptSolver.toEdgeFormat(twoOptSol);
		Set<WeightedEdge> expectedTwoOpt = new HashSet<WeightedEdge>(twoOptEdgeConv);
		
		Set<WeightedEdge> actualTwoOpt = twoOptSolver.searchNeighborhood(nodes, 20);
		
		assertEquals(expectedTwoOpt,actualTwoOpt );
		
	}
	
	@Test
	public void testTourWrapCorner() {
		UndirectedGraph<IntNode,WeightedEdge> graph = new UndirectedSparseGraph<IntNode,WeightedEdge>();
		List<IntNode> nodes = new ArrayList<IntNode>();
		int size = 10;
		for(int i = 0; i < size; i++){
			IntNode node = new IntNode(i);
			nodes.add(node);
			graph.addVertex(node);
		}
		for(int i = 0; i < size; i++ ){
			IntNode nodeI = nodes.get(i);
			for(int j = i+1; j < size; j++){
				IntNode nodeJ = nodes.get(j);
				int weight;
				if(i == 3 && j == 9){
					weight = 1;
				}
				else if(i == 0 && j == 4){
					weight = 1;
				}
				else{
					weight = 2;
				}
				graph.addEdge(new TestEdge<IntNode>(weight,nodeI,nodeJ),nodeI,nodeJ);
			}
		}
		TspInstance<IntNode,WeightedEdge> instance = new TspInstance<IntNode,WeightedEdge>(graph,WeightedEdge.edgeWeights,"simple test");
		TwoOpt<IntNode,WeightedEdge> twoOptSolver = new TwoOpt<IntNode,WeightedEdge>(instance);
		
		List<IntNode> twoOptSol = new ArrayList<IntNode>();
		twoOptSol.add(nodes.get(0));
		twoOptSol.add(nodes.get(1));
		twoOptSol.add(nodes.get(2));
		twoOptSol.add(nodes.get(3));
		twoOptSol.add(nodes.get(9));
		twoOptSol.add(nodes.get(8));
		twoOptSol.add(nodes.get(7));
		twoOptSol.add(nodes.get(6));
		twoOptSol.add(nodes.get(5));
		twoOptSol.add(nodes.get(4));
		
		List<WeightedEdge> twoOptEdgeConv = twoOptSolver.toEdgeFormat(twoOptSol);
		Set<WeightedEdge> expectedTwoOpt = new HashSet<WeightedEdge>(twoOptEdgeConv);
		
		Set<WeightedEdge> actualTwoOpt = twoOptSolver.searchNeighborhood(nodes, 20);
		
		assertEquals(expectedTwoOpt,actualTwoOpt );
		
	}

}
