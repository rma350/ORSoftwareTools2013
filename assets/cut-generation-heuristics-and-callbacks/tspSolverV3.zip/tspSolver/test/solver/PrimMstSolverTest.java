package solver;

import static org.junit.Assert.*;

import instances.IntNode;
import instances.WeightedEdge;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;

public class PrimMstSolverTest {
	
	private static class TestEdge<V> extends WeightedEdge{
		private V first;
		private V second;
		
		public TestEdge(int weight, V first, V second){
			super(weight);
			this.first = first;
			this.second = second;
		}
		
		
		public V getFirst() {
			return first;
		}


		public V getSecond() {
			return second;
		}


		public String toString(){
			return "(" + first.toString()+","+second.toString()+")";
		}
	}
	
	// example from http://en.wikipedia.org/wiki/Prim's_algorithm on Jan 10, 2013

	@Test
	public void test() {
		//a = 0
		//b = 1
		//c = 2
		//d = 3
		//e = 4
		//f = 5
		//g = 6
		UndirectedGraph<IntNode,TestEdge<IntNode>> graph = new UndirectedSparseGraph<IntNode,TestEdge<IntNode>>(); 
		List<IntNode> nodes = new ArrayList<IntNode>();
		for(int i = 0; i<7; i++){
			nodes.add(new IntNode(i));
			graph.addVertex(nodes.get(i));
		}
		Map<TestEdge<IntNode>,Integer> edgeWeights = new HashMap<TestEdge<IntNode>,Integer>();
		Set<TestEdge<IntNode>> solution = new HashSet<TestEdge<IntNode>>();
		solution.add(new TestEdge<IntNode>(5,nodes.get(0),nodes.get(3)));//ad
		solution.add(new TestEdge<IntNode>(7,nodes.get(0),nodes.get(1)));//ab
		solution.add(new TestEdge<IntNode>(7,nodes.get(1),nodes.get(4)));//be
		solution.add(new TestEdge<IntNode>(5,nodes.get(2),nodes.get(4)));//ce
		solution.add(new TestEdge<IntNode>(9,nodes.get(4),nodes.get(6)));//eg
		solution.add(new TestEdge<IntNode>(6,nodes.get(3),nodes.get(5)));//df
		for(TestEdge<IntNode> testEdge: solution){
			graph.addEdge(testEdge, testEdge.getFirst(), testEdge.getSecond());
			edgeWeights.put(testEdge, testEdge.getDistance());
		}
		Set<TestEdge<IntNode>> otherEdges = new HashSet<TestEdge<IntNode>>();
		otherEdges.add(new TestEdge<IntNode>(9,nodes.get(1),nodes.get(3)));//bd
		otherEdges.add(new TestEdge<IntNode>(8,nodes.get(1),nodes.get(2)));//bc
		otherEdges.add(new TestEdge<IntNode>(15,nodes.get(3),nodes.get(4)));//de
		otherEdges.add(new TestEdge<IntNode>(8,nodes.get(4),nodes.get(5)));//ef
		otherEdges.add(new TestEdge<IntNode>(11,nodes.get(5),nodes.get(6)));//fg
		for(TestEdge<IntNode> testEdge: otherEdges){
			graph.addEdge(testEdge, testEdge.getFirst(), testEdge.getSecond());
			edgeWeights.put(testEdge, testEdge.getDistance());
		}
		UndirectedGraph<IntNode,TestEdge<IntNode>> mst = PrimMstSolver.findMst(graph, edgeWeights, nodes.get(3));
		assertEquals(7,mst.getVertexCount());
		assertEquals(new HashSet<IntNode>(nodes),new HashSet<IntNode>(mst.getVertices()));
		assertEquals(6,mst.getEdgeCount());
		assertEquals(solution,new HashSet<TestEdge<IntNode>>(mst.getEdges()));
		
		
		
				
	}

}
