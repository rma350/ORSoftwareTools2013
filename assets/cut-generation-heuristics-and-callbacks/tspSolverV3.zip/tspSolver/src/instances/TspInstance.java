package instances;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections15.Factory;
import org.apache.commons.collections15.Predicate;
import org.apache.commons.collections15.Transformer;

import solver.Util;

import com.google.common.base.Function;

import edu.uci.ics.jung.algorithms.cluster.WeakComponentClusterer;
import edu.uci.ics.jung.algorithms.filters.EdgePredicateFilter;
import edu.uci.ics.jung.algorithms.flows.EdmondsKarpMaxFlow;
import edu.uci.ics.jung.graph.DirectedGraph;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.graph.util.Pair;

public class TspInstance<V,E> {
	
	private UndirectedGraph<V,E> graph;
	private Function<E,Integer> edgeWeights;
	private String name;
	public TspInstance(UndirectedGraph<V, E> graph,
			Function<E, Integer> edgeWeights, String name) {
		super();
		this.graph = graph;
		this.edgeWeights = edgeWeights;
		this.name = name;
	}
	public UndirectedGraph<V, E> getGraph() {
		return graph;
	}
	public Function<E, Integer> getEdgeWeights() {
		return edgeWeights;
	}
	public String getName(){
		return this.name;
	}
	
	public Set<E> cutEdges(Set<V> cutVertices){
		Set<E> ans = new HashSet<E>();
		for(V vertex : graph.getVertices()){
			if(!cutVertices.contains(vertex)){
				for(V cutVertex:cutVertices){
					E cutEdge = graph.findEdge(vertex, cutVertex);
					if(cutEdge != null){
						ans.add(cutEdge);
					}					
				}
			}
		}
		return ans;
	}
	
	public Set<Set<V>> getConnectedComponents(final Set<E> includedEdges){
		Predicate<E> edgesUsed = Util.inSet(includedEdges);
		EdgePredicateFilter<V,E> filter = new EdgePredicateFilter<V,E>(edgesUsed);
		Graph<V,E> subgraph = filter.transform(this.graph);
		WeakComponentClusterer<V,E> clusterer = new WeakComponentClusterer<V,E>();
		return clusterer.transform(subgraph);			
	}
	
	public int cost(Iterable<E> edgeSet){
		int ans = 0;
		for(E edge: edgeSet){
			ans += this.edgeWeights.apply(edge);
		}
		return ans;
	}
	
	
	
	
	
	
	
	

} 