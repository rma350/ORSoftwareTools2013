package instances;

import org.apache.commons.collections15.Transformer;

import com.google.common.base.Function;

public class WeightedEdge {
	int distance;

	public WeightedEdge(int distance) {
		super();
		this.distance = distance;
	}

	public int getDistance() {
		return distance;
	}
	
	public static final Function<WeightedEdge,Integer> edgeWeights = new Function<WeightedEdge,Integer>(){

		@Override
		public Integer apply(WeightedEdge edge) {
			return edge.getDistance();
	}};
	
	public static final Transformer<WeightedEdge,Double> edgeWeightsTrans = new Transformer<WeightedEdge,Double>(){

		@Override
		public Double transform(WeightedEdge edge) {
			return (double)edge.getDistance();
		}};
}
