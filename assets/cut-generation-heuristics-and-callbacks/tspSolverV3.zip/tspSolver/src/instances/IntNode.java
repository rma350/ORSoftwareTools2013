package instances;

public class IntNode {
	
	private int value;

	public IntNode(int value) {
		super();
		this.value = value;
	}

	public int getValue() {
		return value;
	}
	
	public String toString(){
		return ""+value;
	}

}
