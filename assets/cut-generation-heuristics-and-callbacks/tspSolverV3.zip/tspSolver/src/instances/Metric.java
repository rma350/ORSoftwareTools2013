package instances;



public interface Metric {
	public int distance(GeoNode n1, GeoNode n2);
}
