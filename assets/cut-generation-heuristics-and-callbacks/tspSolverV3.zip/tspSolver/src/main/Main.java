package main;

import java.util.EnumSet;

import solver.TspIpSolver;
import solver.TspIpSolver.Option;

import tspLib.TspLibParser;
import tspLib.TspLibParser.UnsupportedFileTypeException;
import ilog.concert.IloException;
import instances.GeoNode;
import instances.TspInstance;
import instances.WeightedEdge;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String[] problemNames = new String[]{"eil51","bier127","ch130","ch150","d198", "d493","d657", "d1291","fl1400"};
		String problemName = problemNames[3];
		System.out.print("Reading file " + problemName + "...");
		TspInstance<GeoNode,WeightedEdge> instance;
		try {
			instance = TspLibParser.parse(problemName);
			System.out.println(" complete!");
		} catch (UnsupportedFileTypeException e) {
			throw new RuntimeException(e);
		}
		TspIpSolver<GeoNode, WeightedEdge> solver;
		try {
			System.out.print("Building problem...");
			solver = new TspIpSolver<GeoNode,WeightedEdge>(instance,EnumSet.of(Option.lazy, Option.userCut));
					//Option.christofidesApprox,Option.christofidesHeuristic, Option.twoOpt, Option.incumbent));
			System.out.println(" complete!");
			System.out.print("Solving TSP...");
			solver.solve();
			System.out.println(" complete!");
		} catch (IloException e) {
			throw new RuntimeException(e);
		}
		System.out.println("opt is: " + solver.getOptVal());
		
	}

}
