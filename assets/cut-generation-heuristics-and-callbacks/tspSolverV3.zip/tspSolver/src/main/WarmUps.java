package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import solver.Util;



import com.google.common.base.Function;
import com.google.common.base.Functions;
import com.google.common.collect.ImmutableBiMap;

import ilog.concert.IloException;
import ilog.concert.IloIntVar;
import ilog.concert.IloLinearIntExpr;
import ilog.cplex.IloCplex;

public class WarmUps {
	
	public static void main(String[] args) {		
		try {
			exerciseOne();
		} catch (IloException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static void exerciseOne() throws IloException{
		IloCplex cplex = new IloCplex();
		//write code here!
		
	}
	
	public static void exerciseTwo() throws IloException{
		List<String> varNames = Arrays.asList("x","y","z");
		Map<String,Integer> weightsMap = new HashMap<String,Integer>();
		weightsMap.put("x",1);
		weightsMap.put("y",2);
		weightsMap.put("z",3);
		Function<String,Integer> weights = Functions.forMap(weightsMap);
		IloCplex cplex = new IloCplex();
		//write code here!
		
	}
	
	public static void testSpeed() throws IloException{
		IloCplex cplex = new IloCplex();
		IloIntVar[] variables = cplex.boolVarArray(2000000);
		cplex.addMaximize(cplex.sum(variables));
		cplex.solve();
		{			
			System.err.println("testing group access");
			long startTime = System.currentTimeMillis();
			double sum = 0;
			double[] vals = cplex.getValues(variables);
			for(int i = 0; i < vals.length; i++){
				sum+= vals[i];
			}
			long endTime = System.currentTimeMillis();
			System.err.println("group: " + (endTime-startTime));
			System.err.println(sum);
		}
		{
			System.err.println("testing individual access");
			long startTime = System.currentTimeMillis();
			double sum = 0;
			for(int i = 0; i < variables.length; i++){
				double val = cplex.getValue(variables[i]);
				sum+=val;
			}
			long endTime = System.currentTimeMillis();
			System.err.println("individual: " + (endTime-startTime));
			System.err.println(sum);
		}		
	}

}
