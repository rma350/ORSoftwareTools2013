package output;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.common.base.CharMatcher;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;

public class NodeLog {
	
	public static void main(String[] args){
		boolean skipBrokenLine = true;
		String fileName = "d493det.txt";
		String inDir = "sampleData" + File.separator + "nodeLogs" + File.separator;
		String outDir = "sampleData" + File.separator + "processedNodeLogs" + File.separator;
		String inFile = inDir+fileName;
		String outFile = outDir + fileName;
		String delimeter = "|";
		List<LogColumn> columns = Arrays.asList(LogColumn.nodes,LogColumn.bestInteger, LogColumn.bestBound);
		boolean printLineIndex =false;
		boolean initDelim = true;
		boolean finalDelim = true;
		boolean titles = false;
		parseLog(skipBrokenLine,inFile,outFile,delimeter,columns,printLineIndex,initDelim,finalDelim,titles);
	}
	
	public enum LogColumn{
		newIncumbent(0),nodes(1),usedHeuristic(1),nodesLeft(2),objective(3),iinf(4), bestInteger(5),bestBound(6),itCnt(7),gap(8);
		
		private final int block;
		
		private LogColumn(int block){
			this.block = block;
		}
		
		public String parseLine(List<String> line, boolean nullOnEmpty){
			boolean newIncumbent = line.get(0).equals("*");
			boolean heuristic = line.get(0).endsWith("+") || line.get(1).endsWith("+");
			if(this == LogColumn.newIncumbent){
				if(newIncumbent){
					return "true";
				}
				else{
					return "false";
				}
			}
			if(this == LogColumn.usedHeuristic){
				if(heuristic){
					return "true";
				}
				else{
					return "false";
				}
			}
			int blockLoc = newIncumbent? block : block-1;
			if(heuristic){
				if(this == LogColumn.objective || this == LogColumn.iinf){
					return nullOnEmpty ? null : "";
				}
				else if(block > 1){
					blockLoc = blockLoc-2;
				}
			}
			else{
				String objective = line.get(newIncumbent ? LogColumn.objective.block : LogColumn.objective.block -1 );
				if(objective.equals("cutoff") || objective.equals("infeasible")){
					if(this == LogColumn.objective || this == LogColumn.iinf){
						return nullOnEmpty ? null : "";
					}
					else if(block > 1){
						blockLoc = blockLoc-1;
					}
				}
			}
			
			String subString = line.get(blockLoc);
			if(this == LogColumn.bestBound){
				try{
					Double.parseDouble(subString);
				}
				catch(NumberFormatException e){
					return nullOnEmpty ? null : "";
				}
			}
			else if(this == LogColumn.nodes){
				if(subString.endsWith("+")){
					subString = subString.substring(0,subString.length()-1);
				}
			}
			else if(this == LogColumn.gap){
				subString  = subString.substring(0,subString.length()-1);
			}
			return subString;						
		}
	}
	
	private static Splitter splitter = Splitter.on(CharMatcher.WHITESPACE).omitEmptyStrings().trimResults();
	
	private static boolean isNodeLogLine(List<String> line){
		if(line.size() < 5){
			return false;
		}
		if(line.get(0).equals("*")){
			return true;
		}
		
		String numNodes = line.get(0);
		if(numNodes.isEmpty()){
			return false;
		}
		try{
			Integer.parseInt(numNodes);
		}
		catch(NumberFormatException e){
			return false;
		}
		return true;		
	}
	
	public static void parseLog(boolean skipBrokenLine, String inputFileName, String outputFileName, String delimeter, List<LogColumn> columns, boolean printLineIndex, boolean initDelim, boolean finalDelim, boolean titles){
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(outputFileName));
			BufferedReader reader = new BufferedReader(new FileReader(inputFileName));
			String nextLine = reader.readLine();
			int lineIndex = 0;
			while(nextLine != null){
				nextLine = nextLine.replaceFirst("\\*", "* ");
				nextLine = nextLine.replaceFirst("\\+", "+ ");
				//System.err.println(nextLine);
				List<String> listLine = Lists.newArrayList(splitter.split(nextLine));
				//System.err.println(listLine);
				if(isNodeLogLine(listLine)){
					boolean lineIsBroken = false;
					StringBuilder outLine = new StringBuilder();
					if(initDelim){
						outLine.append(delimeter);
					}
					if(printLineIndex){
						outLine.append(lineIndex);
						outLine.append(delimeter);						
					}
					for(int i = 0; i < columns.size(); i++){
						String toAppend =columns.get(i).parseLine(listLine,skipBrokenLine);
						if(toAppend == null){
							lineIsBroken = true;
							break;
						}						
						outLine.append(toAppend);
						if(i < columns.size() || finalDelim){
							outLine.append(delimeter);
						}
					}
					if(!lineIsBroken){
						lineIndex++;
						writer.write(outLine.toString());
						writer.newLine();
					}				
				}
				nextLine = reader.readLine();
			}
			reader.close();
			writer.close();
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

}
