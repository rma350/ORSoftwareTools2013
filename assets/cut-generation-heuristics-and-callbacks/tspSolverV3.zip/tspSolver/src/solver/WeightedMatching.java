package solver;

import ilog.concert.IloException;
import ilog.concert.IloIntVar;
import ilog.cplex.IloCplex;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableSet;

import edu.uci.ics.jung.graph.UndirectedGraph;

public class WeightedMatching<V,E> {
	
	private boolean silent = true;
	
	private UndirectedGraph<V,E> graph;
	private Function<E,? extends Number> edgeWeights;
	private IloCplex cplex;
	private ImmutableBiMap<E,IloIntVar> edgeVariables;
	private IloIntVar[] edgeVariablesAsArray;
	private ObjectiveType objectiveType;
	
	private ImmutableSet<E> edgesInOpt;
	private double optVal;
	
	public WeightedMatching(UndirectedGraph<V,E> graph, Function<E,? extends Number> edgeWeights, ObjectiveType objectiveType) throws IloException{
		if(graph.getVertexCount() %2 != 0){
			throw new RuntimeException("Graphs with an odd number of vertices cannot have a perfect matching, this graph has "
					+ graph.getVertexCount() + " vertices");
			
		}
		this.graph = graph;
		this.edgeWeights = edgeWeights;
		this.cplex = new IloCplex();
		if(silent){
		cplex.setOut(null);
		}
		this.edgeVariables = Util.makeBinaryVariables(cplex, graph.getEdges());
		edgeVariablesAsArray = edgeVariables.inverse().keySet().toArray(new IloIntVar[]{});
		//the degree constraints
		for(V vertex: graph.getVertices()){
			cplex.addEq(Util.integerSum(cplex, edgeVariables, 
			graph.getIncidentEdges(vertex)), 1);
		}
		this.objectiveType = objectiveType;
		if(this.objectiveType == ObjectiveType.maximize){
			cplex.addMaximize(Util.sum(
					cplex, edgeVariables, graph.getEdges(),edgeWeights));
		}
		else{
			cplex.addMinimize(Util.sum(
					cplex, edgeVariables, graph.getEdges(),edgeWeights));
		}
		
	}
	
	public static enum ObjectiveType{
		maximize,minimize;
	}
	
	public void solve() throws IloException{
		cplex.solve();
		optVal = cplex.getObjValue();
		edgesInOpt = ImmutableSet.copyOf(edgesUsed(cplex.getValues(edgeVariablesAsArray)));
		cplex.end();
	}
	
	
	
	public ImmutableSet<E> getEdgesInOpt() {
		return edgesInOpt;
	}

	public double getOptVal() {
		return optVal;
	}

	/**
	 * assumes  edgeVarVals[i] in {0,1}, up to some tolerance.  
	 * @param edgeVars
	 * @param edgeVarVals
	 * @return the edges where the variable takes the value one.
	 */
	private Set<E> edgesUsed(double[] edgeVarVals){
		Set<E> ans = new HashSet<E>();
		for(int e = 0; e < edgeVarVals.length; e++){
	        if(Util.doubleToBoolean(edgeVarVals[e])){
	        	ans.add(edgeVariables.inverse().get(edgeVariablesAsArray[e]));
	        }
	    }
		return ans;
	}
}
