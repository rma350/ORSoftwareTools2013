package solver;


import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections15.Factory;
import org.apache.commons.collections15.Transformer;

import edu.uci.ics.jung.algorithms.cluster.WeakComponentClusterer;
import edu.uci.ics.jung.algorithms.flows.EdmondsKarpMaxFlow;
import edu.uci.ics.jung.graph.DirectedGraph;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.util.Pair;

public class MinCutSolver<V,E> {
	
	private UndirectedGraph<V,E> graph;
	private Map<E,Double> edgeWeights;
	private DirectedGraph<V,WrapperEdge> subgraph;
	private Transformer<WrapperEdge,Number> capacities;
	
	private static int rescaling = 50;
	
	public MinCutSolver(UndirectedGraph<V,E> graph, final Map<E,Double> edgeWeights){
		this.graph = graph;
		this.edgeWeights = edgeWeights;
		subgraph = new DirectedSparseGraph<V,WrapperEdge>();
		for(V vertex: graph.getVertices()){
			subgraph.addVertex(vertex);
		}
		for(E edge : graph.getEdges()){
			if(edgeWeights.containsKey(edge)){
				Pair<V> endpoints = graph.getEndpoints(edge);
				subgraph.addEdge(new WrapperEdge(edge), endpoints.getFirst(), endpoints.getSecond() );
				subgraph.addEdge(new WrapperEdge(edge), endpoints.getSecond(), endpoints.getFirst() );
			}
		}
		capacities = new Transformer<WrapperEdge,Number>(){
			@Override
			public Number transform(WrapperEdge wrapperEdge) {
				if(!edgeWeights.containsKey(wrapperEdge.getEdge())){
					throw new RuntimeException();
				}
				return Math.round(edgeWeights.get(wrapperEdge.getEdge()).doubleValue()*rescaling);
			}			
		};
	}
	
	public Set<Set<V>> checkConnectedComponents(){
		WeakComponentClusterer<V,WrapperEdge> clusterer = new WeakComponentClusterer<V,WrapperEdge>();
		return clusterer.transform(subgraph);
	}
	
	public Set<V> computeMinCut(V source, V sink){		
		
		Map<WrapperEdge,Number> flowQuantities = new HashMap<WrapperEdge,Number>();
		EdmondsKarpMaxFlow<V,WrapperEdge> maxFlow = new EdmondsKarpMaxFlow<V,WrapperEdge>(
				subgraph,source,sink,capacities,flowQuantities,new WrapperEdgeFactory());
		maxFlow.evaluate();
		Set<V> sourceComponent = maxFlow.getNodesInSourcePartition();
		return sourceComponent;
	}
	
	
	private class WrapperEdge{
		private E edge;
		
		public WrapperEdge(E edge){
			this.edge = edge;
		}
		
		public E getEdge(){
			return edge;
		}
	}
	
	
	
	
	private class WrapperEdgeFactory implements Factory<WrapperEdge> {
		
		public WrapperEdgeFactory(){}

		@Override
		public WrapperEdge create() {
			return new WrapperEdge(null);
		}
		
	}

}
