package solver;

import instances.TspInstance;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.common.base.Function;

import edu.uci.ics.jung.graph.UndirectedGraph;

public class TwoOpt<V,E> {
	
	private Set<Set<E>> alreadyConsidered;
	private TspInstance<V,E> tspInstance;
	private int defaultMaxRecursionDepth;
	
	public TwoOpt(TspInstance<V,E> tspInstance){
		this.alreadyConsidered = new HashSet<Set<E>>();
		this.tspInstance = tspInstance;
		defaultMaxRecursionDepth = 500;
	}
	
	/**
	 * Warning, converting the Set tour must be converted to a list which takes O(V^2)
	 * @param tour
	 * @return a locally optimal tour, or null if an already visited tour is hit.
	 */
	public Set<E> searchNeighborhoodEdgeSet(Set<E> tour){
		return searchNeighborhoodEdgeList(this.toEdgeListFormat(tour));
	}
	
	/**
	 * 
	 * @param tour
	 * @return a locally optimal tour, or null if an already visited tour is hit.
	 */
	public Set<E> searchNeighborhoodEdgeList(List<E> tour){
		return searchNeighborhoodVertexList(toVertexFormat(tour));
	}
	public Set<E> searchNeighborhoodVertexList(List<V> tour){
		System.out.print("entering two opt, cost " + tspInstance.cost(toEdgeFormat(tour)));
		return searchNeighborhood(tour,defaultMaxRecursionDepth);
	}
	Set<E> searchNeighborhood(List<V> tour, int maxRecursionDepth){
		
		List<E> tourInEdges = toEdgeFormat(tour);
		Set<E> tourAsSet = new HashSet<E>(tourInEdges);
		if(alreadyConsidered.contains(tourAsSet)){
			return null;
		}		
		else{
			alreadyConsidered.add(tourAsSet);
			if(maxRecursionDepth == 0){
				System.err.println("Warning: hit maximum recursion depth on two opt");
				return tourAsSet;				
			}
			UndirectedGraph<V,E> graph = tspInstance.getGraph();
			Function<E,Integer> edgeCosts = tspInstance.getEdgeWeights();
			int baseTourCost = tspInstance.cost(tourInEdges); 
			int bestCost = baseTourCost;
			int bestI = -1;
			int bestJ = -1;			
			for(int i = 0; i < tour.size(); i++){
				V a = tour.get(i);
				V b = tour.get((i+1)%tour.size());
				E ab = graph.findEdge(a,b);
				
				for(int j = i+2; j < tour.size(); j++){
					V c = tour.get(j);
					V d = tour.get((j+1)%tour.size());
					E cd = graph.findEdge(c, d);
					
					E ac = graph.findEdge(a, c);
					E bd = graph.findEdge(b, d);
					int ijSwapCost = baseTourCost - edgeCosts.apply(ab) - edgeCosts.apply(cd) + edgeCosts.apply(ac) + edgeCosts.apply(bd);
					if(ijSwapCost < bestCost){
						bestI = i;
						bestJ = j;
						bestCost = ijSwapCost;
					}
				}
			}
			if(bestI ==  -1){
				System.out.println(" exit depth: " + 
						(this.defaultMaxRecursionDepth - maxRecursionDepth) + " cost " + bestCost);
				return tourAsSet;
			}
			else{
				List<V> nextTour = new ArrayList<V>();
				for(int k = 0; k <= bestI; k++){
					nextTour.add(tour.get(k));
				}
				for(int k = bestJ; k > bestI; k--){
					nextTour.add(tour.get(k));
				}
				for(int k = bestJ+1; k < tour.size(); k++){
					nextTour.add(tour.get(k));
				}
				return searchNeighborhood(nextTour,maxRecursionDepth-1);
			}
		}
	}
	
	//be careful, runs in O(n) time...
	//converts a list of n nodes to a list of n edges, e.g.
	//toEdgeFormat({3,1,4,2}) -> {(3,1),(1,4),(4,2),(2,3)
	List<E> toEdgeFormat(List<V> tour){
		List<E> ans = new ArrayList<E>();
		for(int i = 1; i < tour.size(); i++){
			ans.add(tspInstance.getGraph().findEdge(tour.get(i-1), tour.get(i)));
		}
		ans.add(tspInstance.getGraph().findEdge(tour.get(tour.size()-1), tour.get(0)));
		return ans;
	}
	
	/**
	 * Be careful, this runs pretty slowly! O(V^2)
	 * @param tour
	 * @return
	 */
	List<E> toEdgeListFormat(Set<E> tour){
		UndirectedGraph<V,E> graph = this.tspInstance.getGraph();
		Set<E> tourCopy = new HashSet<E>(tour);
		List<E> ans = new ArrayList<E>();
		E next= tour.iterator().next();
		ans.add(next);
		tourCopy.remove(next);
		while(ans.size() < graph.getVertexCount()){
			E matching = null;
			for(E edge: tourCopy){
				boolean match = false;
				for(V first: graph.getEndpoints(next)){
					for(V second: graph.getEndpoints(edge)){
						if(first == second){
							match = true;
						}
					}
				}
				if(match){
					matching = edge;
					break;
				}
			}
			if(matching == null){
				throw new RuntimeException("Unreachable");
			}
			else{
				ans.add(matching);
				tourCopy.remove(matching);
				next = matching;
			}
		}
		return ans;
		
	}
	
	List<V> toVertexFormat(List<E> tour){
		List<V> ans = new ArrayList<V>();
		for(int i = 0; i < tour.size(); i++){
			ans.add(getIntersection(tour.get(i),tour.get((i+1)%tour.size())));
		}
		return ans;
	}
	
	private V getIntersection(E firstEdge, E secondEdge){
		for(V first: tspInstance.getGraph().getEndpoints(firstEdge)){
			for(V second: tspInstance.getGraph().getEndpoints(secondEdge)){
				if(first == second){
					return first;
				}
			}
		}
		throw new RuntimeException("Unreachable");
		
	}

}
