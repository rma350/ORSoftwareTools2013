package solver;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;

public class PrimMstSolver {
	
	private static class EdgeEntry <V,E> {
		private V source;
		private E edge;
		private double distance;


		public EdgeEntry(V source, E edge, double distance) {
			this.source = source;
			this.edge = edge;
			this.distance = distance;
		}

		public V getSource() {
			return source;
		}

		public E getEdge() {
			return edge;
		}

		public double getDistance() {
			return distance;
		}

	}
	
	public static <V,E> UndirectedGraph<V,E> findMst(UndirectedGraph<V,E> graph, Map<E,? extends Number> edgeWeights){
		return findMst(graph,edgeWeights,graph.getVertices().iterator().next());
	}
	
	/**
	 * Runs in O(V^2)
	 * @param graph 
	 * @param edgeWeights
	 * @param root where prims algorithm begins
	 * @return
	 */
	public static <V,E> UndirectedGraph<V,E> findMst(UndirectedGraph<V,E> graph, Map<E,? extends Number> edgeWeights, V root){
	
		UndirectedGraph<V,E> tree = new UndirectedSparseGraph<V,E>();
		for(V vertex: graph.getVertices()){
			tree.addVertex(vertex);
		}
		V nextSource = root;
		Set<V> visited = new HashSet<V>();
		visited.add(nextSource);		
		//a node on the frontier, the distance to the node, then the visited node reaching it at this distance
		Map<V,EdgeEntry<V,E>> frontierDistance = new HashMap<V,EdgeEntry<V,E>>();
		while(visited.size()< graph.getVertexCount()){
			//update the frontier
			for(E edge: graph.getIncidentEdges(nextSource)){
				V opposite = graph.getOpposite(nextSource, edge);	
				if(!visited.contains(opposite)){
					if(!frontierDistance.containsKey(opposite) ||
							frontierDistance.get(opposite).getDistance() > 	edgeWeights.get(edge).doubleValue()){
						frontierDistance.put(opposite, new EdgeEntry<V,E>(nextSource,
								edge,edgeWeights.get(edge).doubleValue()));
					}
				}
			}
			//pick the closest node on the frontier
			double best = Double.MAX_VALUE;
			EdgeEntry<V,E> bestEdgeEntry = null;
			V bestTarget = null;
			for(V vertex: frontierDistance.keySet()){
					EdgeEntry<V,E> testEdge = frontierDistance.get(vertex);
					if(testEdge.getDistance() < best){
						best = testEdge.getDistance();
						bestEdgeEntry = testEdge;
						bestTarget = vertex;
					}				
			}
			if(bestEdgeEntry == null){
				throw new RuntimeException();
			}
			tree.addEdge(bestEdgeEntry.getEdge(), bestEdgeEntry.getSource(), bestTarget );
			nextSource = bestTarget;
			frontierDistance.remove(bestTarget);
			visited.add(bestTarget);
		}
		return tree;
	}

}
