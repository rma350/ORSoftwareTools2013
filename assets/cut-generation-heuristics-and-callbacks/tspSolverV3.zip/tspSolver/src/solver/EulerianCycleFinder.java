package solver;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jgrapht.alg.EulerianCircuit;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.Multigraph;
import org.jgrapht.graph.SimpleGraph;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.util.Pair;

public class EulerianCycleFinder {
	
	/**
	 * @param graph
	 * @return
	 */
	public static <V,E> List<V> findCycle(UndirectedGraph<V,E> baseGraph, UndirectedGraph<V,E> minimumSpanningTree, Set<E> oddDegreeMatchingEdges){
		Multigraph<V,DefaultEdge> jGraph = new Multigraph<V,DefaultEdge>(DefaultEdge.class);
		for(V vertex: minimumSpanningTree.getVertices()){
			jGraph.addVertex(vertex);
		}
		for(E edge: minimumSpanningTree.getEdges()){			
			Pair<V> endpoints = minimumSpanningTree.getEndpoints(edge);
			DefaultEdge jEdge = jGraph.addEdge(endpoints.getFirst(), endpoints.getSecond());
		}
		for(E edge: oddDegreeMatchingEdges){
			Pair<V> endpoints = baseGraph.getEndpoints(edge);
			DefaultEdge jEdge = jGraph.addEdge(endpoints.getFirst(), endpoints.getSecond());
		}
		/*for(V vertex: jGraph.vertexSet()){
			if(jGraph.edgesOf(vertex).size() % 2 != 0){
				throw new RuntimeException("vertex "+ vertex.toString() + " has odd degree of " + jGraph.edgesOf(vertex).size() );
			}
		}*/
		List<V> jEuler = EulerianCircuit.getEulerianCircuitVertices(jGraph);
		if(jEuler == null){
			throw new RuntimeException("Graph is not Eulerian");
		}
		return jEuler;
	}
	
	

}
