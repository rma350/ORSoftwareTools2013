package solver;

import java.util.Map;
import java.util.Set;

import org.apache.commons.collections15.Predicate;

import ilog.concert.IloException;
import ilog.concert.IloIntVar;
import ilog.concert.IloLinearIntExpr;
import ilog.concert.IloLinearNumExpr;
import ilog.cplex.IloCplex;

import com.google.common.base.Function;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableBiMap.Builder;

public class Util {

	/**
	 * 
	 * @param cplex
	 * @param set must contain no duplicates according to T.equals(), a duplicate causes an illegal argument exception
	 * @return
	 * @throws IloException
	 */
	public static <T> ImmutableBiMap<T,IloIntVar> makeBinaryVariables(IloCplex cplex, Iterable<T> set) throws IloException{
		Builder<T,IloIntVar> ans = ImmutableBiMap.builder();
		for(T t: set){
			ans.put(t, cplex.boolVar());
		}
		return ans.build();
	}

	public static <T> IloLinearIntExpr integerSum(IloCplex cplex, 
			BiMap<T,IloIntVar> variables, Iterable<T> set, 
			Function<? super T,Integer> coefficients) throws IloException{
		IloLinearIntExpr sum = cplex.linearIntExpr();
		for(T t: set){
			sum.addTerm(variables.get(t), coefficients.apply(t));
		}
		return sum;
	}

	public static <T> IloLinearNumExpr sum(IloCplex cplex, 
			BiMap<T,IloIntVar> variables, Iterable<T> set, 
			Function<? super T,? extends Number> coefficients) throws IloException{
		IloLinearNumExpr sum = cplex.linearNumExpr();
		for(T t: set){
			sum.addTerm(variables.get(t), coefficients.apply(t).doubleValue());
		}
		return sum;
	}

	public static <T> IloLinearIntExpr integerSum(IloCplex cplex, 
			BiMap<T,IloIntVar> variables, Iterable<T> set) throws IloException{
		return integerSum(cplex,variables,set,unity);
	}

	private static Function<Object,Integer> unity = new Function<Object,Integer>(){
		@Override
		public Integer apply(Object arg0) {
			return 1;
		}};

	public static double epsilon = .000001;

	public static boolean doubleToBoolean(double value){
		if(Math.abs(1-value) < epsilon ){
			return true;
		}
		else if(Math.abs(value) < epsilon){
			return false;
		}
		else throw new RuntimeException("Failed to convert to boolean, not near zero or one: " + value);
	}
	
	public static <T> Predicate<T> inSet(final Set<T> set){
		return new Predicate<T>(){
			@Override
			public boolean evaluate(T arg0) {
				return set.contains(arg0);
			}			
		};
	}
	
	public static <E> double calcSum(Set<E> set, Map<E,Double> weights){
		double ans = 0;
		for(E element: set){
			if(weights.containsKey(element)){
				ans+= weights.get(element);
			}
		}
		return ans;
	}

}
