package solver;

import ilog.concert.IloException;
import instances.GeoNode;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections15.Predicate;
import org.apache.commons.collections15.Transformer;

import solver.WeightedMatching.ObjectiveType;

import com.google.common.base.Function;

import edu.uci.ics.jung.algorithms.cluster.WeakComponentClusterer;
import edu.uci.ics.jung.algorithms.filters.EdgePredicateFilter;
import edu.uci.ics.jung.algorithms.filters.VertexPredicateFilter;
import edu.uci.ics.jung.algorithms.shortestpath.PrimMinimumSpanningTree;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.graph.util.Pair;

public class ChristofidesSolver<V,E> {
	
	private UndirectedGraph<V,E> graph;
	private Function<E,Integer> edgeCosts;
	
	public ChristofidesSolver(UndirectedGraph<V,E> graph, Function<E,Integer> edgeCosts){
		this.graph = graph;
		this.edgeCosts = edgeCosts;
	}
	
	public List<E> approximateBestTour(final Set<E> suggestedEdges) throws IloException{
		
		EdgePredicateFilter<V,E> suggestionFilter = new EdgePredicateFilter<V,E>(Util.inSet(suggestedEdges));
		UndirectedGraph<V,E> inclusionOnly = (UndirectedGraph<V,E>)suggestionFilter.transform(graph);
		WeakComponentClusterer<V,E> clusterer = new WeakComponentClusterer<V,E>();
		Set<Set<V>> includedClusters =  clusterer.transform(inclusionOnly);
		for(Set<V> includedCluster : includedClusters){
			int edgeCount = 0;
			for(V vertex: includedCluster){
				edgeCount+= inclusionOnly.getNeighborCount(vertex);
			}
			if(includedCluster.size() > 0 && edgeCount == 2*includedCluster.size()){
				System.err.println("found a loop");
				return null;
			}
		}
		
		final Set<V> suggestedOnce = new HashSet<V>();
		final Set<V> suggestedTwice = new HashSet<V>();
		for(E edge: suggestedEdges){
			for(V v : graph.getEndpoints(edge)){
				if(suggestedTwice.contains(v)){
					throw new RuntimeException("Unreachable");
				}
				else if(suggestedOnce.contains(v)){
					suggestedOnce.remove(v);
					suggestedTwice.add(v);
				}
				else{
					suggestedOnce.add(v);
				}
			}
		}
		double largeWeight = 0;
		for(E edge: graph.getEdges()){
			largeWeight = Math.max(largeWeight, 10*edgeCosts.apply(edge));
		}
		final double heaviest = largeWeight;
		Map<E,Double> spanTreeWeights = new HashMap<E,Double>();
		for(E edge: graph.getEdges()){
			if(suggestedEdges.contains(edge)){
				spanTreeWeights.put(edge, 0.0);
			}
			else{
					Pair<V> endpoints = graph.getEndpoints(edge);
					if(suggestedTwice.contains(endpoints.getFirst())|| suggestedTwice.contains(endpoints.getSecond())){
						spanTreeWeights.put(edge, heaviest);;
					}
					else{
						spanTreeWeights.put(edge,Double.valueOf(edgeCosts.apply(edge)));
					}				
			}	
		}
		//PrimMinimumSpanningTree<V,E> spanningTreeSolver = new PrimMinimumSpanningTree<V,E>(UndirectedSparseGraph.<V,E>getFactory(),spanTreeWeights);
		System.out.print("Solving for spanning tree...");
		UndirectedGraph<V,E> spanningTree = PrimMstSolver.findMst(graph, spanTreeWeights);//(UndirectedGraph)spanningTreeSolver.transform(graph);
		System.out.println(" complete");
		final Set<V> oddDegree = new HashSet<V>();
		for(V vertex: spanningTree.getVertices()){
			if(spanningTree.degree(vertex) %2 !=0){
				oddDegree.add(vertex);
			}
		}
		
		Predicate<V> ofOddDegree = Util.inSet(oddDegree);
		VertexPredicateFilter<V,E> filter = new VertexPredicateFilter<V,E>(ofOddDegree);
		UndirectedGraph<V,E> oddGraph = (UndirectedGraph)filter.transform(graph);
		WeightedMatching<V,E> oddMatching = new WeightedMatching<V,E>(oddGraph, edgeCosts, ObjectiveType.minimize);
		System.out.print("Solving for odd matching...");
		oddMatching.solve();
		System.out.println("Complete.");
		Set<E> extraEdgesForOdd = oddMatching.getEdgesInOpt();
		System.out.print("Solving for odd Eulerian cycle...");
		List<V> eulerianCycle = EulerianCycleFinder.findCycle(graph,spanningTree,extraEdgesForOdd);
		System.out.println("Complete.");
		List<E> ans = shortCut(eulerianCycle);
		return ans;
	}
	
	
	private List<E> shortCut(List<V> eulerianCycle){
		List<E> ans = new ArrayList<E>();
		Set<V> visited = new HashSet<V>();
		V nextSource = eulerianCycle.get(0);
		visited.add(nextSource);
		for(int i = 1; i < eulerianCycle.size(); i++){
			V nextTarget = eulerianCycle.get(i);
			if(!visited.contains(nextTarget)){
				visited.add(nextTarget);
				E edge = graph.findEdge(nextSource, nextTarget);
				ans.add(edge);
				nextSource = nextTarget;
			}			
		}
		ans.add(graph.findEdge(nextSource, eulerianCycle.get(0)));
		return ans;		
	}
	
	
	

}
