package solver;

public abstract class BackOffFunction {

	private int numAttemptsSinceEvent;
	private int attemptsUntilNextEvent;
	
	protected BackOffFunction(int attemptsUntilNextEvent){
		numAttemptsSinceEvent = 0;
		this.attemptsUntilNextEvent = attemptsUntilNextEvent;
	}
	
	protected abstract int nextWaitingPeriod();
	
	protected int getAttemptsUntilNextEvent(){
		return attemptsUntilNextEvent;
	}
	
	/**
	 * Logs that an attempt has been made.  Will return true every "so many" attempts,
	 * where behavior is determined by the subclass.
	 * @return
	 */
	public boolean makeAttempt(){
		this.numAttemptsSinceEvent++;
		if(numAttemptsSinceEvent >= attemptsUntilNextEvent){
			attemptsUntilNextEvent = nextWaitingPeriod();
			numAttemptsSinceEvent = 0;
			//System.err.println(true);
			return true;
		}
		//System.err.println(false);
		return false;
	}
	
	/**
	 * Each waiting period is of constant length
	 * @author ross
	 *
	 */
	public static class ConstantWaiting extends BackOffFunction {
		
		public ConstantWaiting(int waitingPeriod){
			super(waitingPeriod);			
		}

		@Override
		protected int nextWaitingPeriod() {
			return getAttemptsUntilNextEvent();
		}
	}
	
	/**
	 * The nth waiting period is of length n
	 * @author ross
	 *
	 */
	public static class LinearWaiting extends BackOffFunction {		
		public LinearWaiting(){
			super(1);			
		}
		@Override
		protected int nextWaitingPeriod() {
			return getAttemptsUntilNextEvent()+1;
		}
	}
	
	/**
	 * The nth waiting period is of length n^2
	 * @author ross
	 *
	 */
	public static class QuadraticWaiting extends BackOffFunction {
		int waitingPeriod;
		
		public QuadraticWaiting(){
			super(1);
			waitingPeriod = 1;
		}
		@Override
		protected int nextWaitingPeriod() {
			waitingPeriod++;
			return waitingPeriod*waitingPeriod;
		}
	}
	
	/**
	 * The nth waiting period is of length 2^n
	 * @author ross
	 *
	 */
	public static class ExponentialWaiting extends BackOffFunction {		
		public ExponentialWaiting(){
			super(1);			
		}
		@Override
		protected int nextWaitingPeriod() {
			return getAttemptsUntilNextEvent()*2;
		}
	}
	
	
	/**
	 * always returns false
	 * @author ross
	 *
	 */
	public static class InfiniteWating extends BackOffFunction {		
		public InfiniteWating(){
			super(1);			
		}
		@Override
		protected int nextWaitingPeriod() {
			return 1;
		}
		public boolean makeAttempt(){
			return false;
		}
	}

	
	
}
